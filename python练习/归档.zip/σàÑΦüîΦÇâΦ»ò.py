a,b =(input().split())
if int(a)>=120 and b == 'A':
    print("通过")
else:
    print("不通过")
