for i in range(1,5,2):
    print(i, end='')
