a=b=[1,2,3]
a[1]='hello'
b[2]='ok'
print(a[1],a[2],b[1],b[2])
