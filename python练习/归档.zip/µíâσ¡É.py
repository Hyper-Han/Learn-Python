peach = int(input("桃子的重量(斤)："))
if peach < 10 :
    price = peach*10
elif peach >=10 :
    price = peach*9
print(price)
                          
